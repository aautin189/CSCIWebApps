Abby Autin
CSCI 4208
Lab #3
January 28, 2020


ABOUT:

We used the html from Lab #1 (home page) to style our home page. We did this using Bootstrap. 

We were able to insert/import (bootstrap) links into the HTML, which provided us access to their CSS libraries. 

This process was far less labor-intensive compared to manually writing CSS like we did in Lab 1. 




