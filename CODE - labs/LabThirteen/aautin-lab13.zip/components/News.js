const {Container} = Reactstrap;

class News extends React.Component{
	render(){
		return(
			<Container className="bg-danger">
				<h1>Welcome</h1>
				<hr/>
				<p>This section summarizes what the page is about and its purpose.</p>
			</Container>
		);
	}
}