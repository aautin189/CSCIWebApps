class App extends React.Component {
	render() {
		return (
			<div>
				<TopNavbar />
				<Welcome />
				<News />
				<About />
				<Blog />
				<Projects />
				<ContactForm />
			</div>
		);
	}
}