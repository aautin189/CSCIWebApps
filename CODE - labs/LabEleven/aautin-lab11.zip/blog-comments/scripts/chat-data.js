// Data: POST REQUEST KEYS
const formId = "1FAIpQLSckvnQc6go78e2k7AxBTd196-86djMFOxD8OO06amyDO38hQA";
const name = "entry.1958619267";
const message = "entry.2028067426";


// Data: URL REQUEST
const urlPOST = `https://docs.google.com/forms/d/e/${formId}/formResponse`;


// Data: GET REQUESTS
let sheetId = '13snSv6OOIjo0Zu9A0nNtmjS7QB79bJ6d6oeWx0W1KHk';
const key = "AIzaSyABUrrV8Oefp34cx6ZqSEKM57e-H-jcClQ";
const sheet = encodeURIComponent('Form Responses 1');
const urlGET = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/${sheet}?key=${key}`;























